# GeoMap.js


DEMO: <http://xbingoz.com/public/pages/geomap.html>


## 概述

* GeoMap.js是一个绘制矢量地图控件，基于jQuery、Raphael，

* 支持geoJSON格式的数据源

* 通过Raphael绘制地图，默认采用svg，低版本IE采用vml，兼容性较好



## 文件结构

	json/				//地图数据 ( 省份地图数据来自dataV.js项目 )
	old/				//旧版本备份
	src/				//开发文件
	geomap-x.x.x.js		//发布文件
	api.md				//说明文档



